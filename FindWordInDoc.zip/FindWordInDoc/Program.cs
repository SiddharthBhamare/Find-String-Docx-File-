﻿using Microsoft.Office.Interop.Word;
using System.Runtime.InteropServices;
using Microsoft.Office.Core;
using System;
using System.IO;
using System.Collections.Generic;

namespace FindWordInDoc
{
    class Program
    {
        Object oMissing = System.Reflection.Missing.Value;
        Application word = new Application();
        Document doc = new Document();
        static List<string> fileNames = new List<string>();
        public static bool FindSubStringInDocx(string strFileFullPath, string strSubStringFind)
        {
            var app = new Application();
            var doc = app.Documents.Open(strFileFullPath);
            var range = doc.Range();
            if(range.Find.Execute(FindText:strSubStringFind))
            {
                app.Quit();
                return true;
            }
            else
            {
                app.Quit();
                return false;
            }
        }
        static void Main(string[] args)
        {
           
            string[] arrFileList = Directory.GetFiles(@"D:\Projects\", "*.docx",SearchOption.AllDirectories);
            foreach (string file in arrFileList)
            {
                if(Program.FindSubStringInDocx(file, "Siddharth"))
                {
                    int countLenght = (@"D:\Projects\").Length;
                    fileNames.Add(file.Remove(0, countLenght));
                }
                else
                {
                    fileNames.Add("Content not found");
                }
            }
            
            if(fileNames.Count>0)
            {
                using (StreamWriter file= new StreamWriter(@"D:\Projects\Finallist.txt",true))
                {
                    foreach (var item in fileNames)
                    {
                        file.WriteLine(item);
                    }
                }    
            }
            Console.ReadKey();
        }
    }
}
